from DAL.UserDAO import SysUser
from passlib.context import CryptContext
import io, contextlib


class UserService:
    # Create CryptContext once (don’t re-initialize every call)
    _pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

    def __init__(self):
        self.user = SysUser()

    def add_user(self, Name: str, Address: str, Email: str,
                 RoleID: str, Password: str, Phone: str) -> None:
        """Hash password and add new user record."""
        # Silence passlib/bcrypt stderr noise if needed
        with contextlib.redirect_stderr(io.StringIO()):
            hashed_password = self._pwd_context.hash(Password)

        # Debugging only — remove in production
        # print(hashed_password)

        self.user.add_user(Name, Address, Email, RoleID, hashed_password, Phone)

    def user_exists(self, Email: str) -> bool:
        """Check if a user exists by email."""
        return self.user.check_user_exists(Email)

    def login(self, Email: str, Password: str) -> str | None:
        """Authenticate user by email & password. 
        Returns session string 'userID|roleID' or None."""
        user_data = self.user.get_user_by_email(Email)

        if not user_data:
            print("User with that email does not exist.")
            return None

        user_id, stored_password_hash, role_id = user_data

        # Verify password (quietly ignore bcrypt warnings in frozen apps)
        with contextlib.redirect_stderr(io.StringIO()):
            valid = self._pwd_context.verify(Password, stored_password_hash)

        if valid:
            print("Login successful!")
            return f"{user_id}|{role_id}"
        else:
            print("Incorrect password.")
            return None
