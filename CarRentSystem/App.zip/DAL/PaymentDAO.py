from database import create_connection
import sqlite3

class SysPayment():
    def add_payment(self, BookID, Amount, Status, CreatedBy):
        conn = create_connection()
        cursor = conn.cursor()
        try:
            cursor.execute(
                "INSERT INTO SysPayment (BookID, Amount, Status, CreatedBy) VALUES (?, ?, ?, ?)",
                (BookID, Amount, Status, CreatedBy)
            )
            conn.commit()
            print("Payment added!")
        except sqlite3.Error as e:
            print(f"SQL error: {e}")
        finally:
            conn.close()

    def update_payment_status(self, PayID, Status):
        conn = create_connection()
        cursor = conn.cursor()
        try:
            cursor.execute(
                "UPDATE SysPayment SET Status = ? WHERE PayID = ?",
                (Status, PayID)
            )
            conn.commit()
            print("Status updated successfully.")
        except sqlite3.Error as e:
            print(f"SQL error: {e}")
        finally:
            conn.close()