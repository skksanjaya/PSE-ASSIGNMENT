from database import create_connection
import sqlite3

class SysCharge():
    def add_charge(self, BookID, Amount, CreatedBy):
        conn = create_connection()
        cursor = conn.cursor()
        try:
            cursor.execute(
                "INSERT INTO SysCharge (BookID, Amount, CreatedBy) VALUES (?, ?, ?)",
                (BookID, Amount, CreatedBy)
            )
            conn.commit()
            print("Charge added successfully.")
        except sqlite3.Error as e:
            print(f"Database error: {e}")
        finally:
            conn.close()

    def update_charge_status(self, ChargeID, Amount):
        conn = create_connection()
        cursor = conn.cursor()
        try:
            cursor.execute(
                "UPDATE SysCharge SET Amount = ? WHERE ChargeID = ?",
                (Amount, ChargeID)
            )
            conn.commit()
            print("Charge amount updated successfully.")
        except sqlite3.Error as e:
            print(f"Database error: {e}")
        finally:
            conn.close()