from DAL.CarDAO import SysCar

class CarService():
    def __init__(self):
        self.car_dao = SysCar()

    def view_cars(self):
        """
        Retrieves and displays all cars in the system.
        """
        cars = self.car_dao.view_all_cars()
        if cars:
            print("\n==== Available Cars ====")
            for car in cars:
                # Assuming the SysCar table columns are:
                # CarID, Make, Model, Year, Mileage, Available, MinDays, MaxDays, DailyRate, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate
                print(f"ID: {car[0]}, Make: {car[1]}, Model: {car[2]}, Year: {car[3]}, Daily Rate: ${car[8]}")
        else:
            print("No cars found in the system.")

    def add_car(self, Make, Model, Year, Mileage, DailyRate, CreatedBy):
        """
        Handles the logic for adding a new car.
        """
        # Basic data validation (can be expanded)
        if not all([Make, Model, Year, DailyRate, CreatedBy]):
            print("Error: All fields (Make, Model, Year, DailyRate) are required.")
            return

        # Assuming Year, Mileage, and DailyRate are numbers
        try:
            Year = int(Year)
            Mileage = int(Mileage)
            DailyRate = float(DailyRate)
        except ValueError:
            print("Error: Year, Mileage, and DailyRate must be numbers.")
            return

        self.car_dao.add_car(Make, Model, Year, Mileage, DailyRate, CreatedBy)

    def update_car(self, CarID, updates, ModifiedBy):
        """
        Handles the logic for updating an existing car.
        'updates' is a dictionary of fields to update.
        """
        if not self.car_dao.update_car(CarID, updates, ModifiedBy):
            print("Car update failed. Please check the Car ID.")

    def delete_car(self, CarID):
        """
        Handles the logic for deleting a car.
        """
        if not self.car_dao.delete_car(CarID):
            print("Car deletion failed. Please check the Car ID.")