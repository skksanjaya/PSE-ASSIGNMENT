from database import create_connection
import sqlite3

class SysBooking():
    def view_all_bookings(self):
        conn = create_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("SELECT * FROM SysBooking")
            bookings = cursor.fetchall()
            return bookings
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            return None
        finally:
            conn.close()

    def add_booking(self, CustID, CarID, StartDate, EndDate, CreatedBy):
        conn = create_connection()
        cursor = conn.cursor()
        try:
            cursor.execute(
                "INSERT INTO SysBooking (CustID, CarID, StartDate, EndDate, Status, CreatedBy) VALUES (?, ?, ?, ?, ?, ?)",
                (CustID, CarID, StartDate, EndDate, '1', CreatedBy)
            )
            conn.commit()
            print("Booking added successfully.")
        except sqlite3.Error as e:
            print(f"Database error: {e}")
        finally:
            conn.close()

    def update_booking_status(self, BookID, Status, ApproveBy=None):
        conn = create_connection()
        cursor = conn.cursor()
        try:
            if ApproveBy:
                cursor.execute(
                    "UPDATE SysBooking SET Status = ?, ApproveBy = ?, ApproveDate = datetime('now') WHERE BookID = ?",
                    (Status, ApproveBy, BookID)
                )
            else:
                cursor.execute(
                    "UPDATE SysBooking SET Status = ? WHERE BookID = ?",
                    (Status, BookID)
                )
            conn.commit()
            print("Booking status updated successfully.")
        except sqlite3.Error as e:
            print(f"Database error: {e}")
        finally:
            conn.close()